Pixel Planets Pack
A 32x32 pixel art asset pack featuring planets, comets, meteorites etc. pixel art objects.
47 Planets(13 based on real planets, 34 fictional planets)
1 blackhole
4 meteorite
4 galaxy
8 comet
Includes 64 unique designs, each with an outlined and an outline-free version, for a total of 128 assets.
PNG format with transparent backgrounds, provided in three sizes: 32x32 (original size), 64x64 and 128x128 pixels.


You can
Using this asset pack in both personal and commercial projects
Using this asset pack in your game, video, livestreams, illustration, and other creative works
Modifying the assets, including changing their color, sizes, or any editing as needed

Please Don't
Resell, redistribute or repackage the original or modified assets as an asset pack
Claim the assets as your own work, and resell or redistribute as your own creations
Sell products in which the original or modified assets are the primary content
Use the assets to create or sell NFTs featuring the assets themselves
Input the assets into generative AI systems for image generation
Use the assets as training data for generative AI models
Use these assets for harassment, defamation, or abuse targeting individuals, companies, or organizations
Use these assets for political campaigning, promotion, or advocacy


Attribution is not necessary but always appreciated.

The author retains all copyrights to these assets.
The author is not responsible for any issues or damages arising from the use of these assets.
The contents of this asset pack and its terms of use may be updated as needed.

23 Oct. 2026
冬角 / Tokaku
https://x.com/jack_alope_to
tokaku.jackalope@gmail.com

-------------------------------

26 Oct. 2026  Fixed typo
