import sys
from pathlib import Path
r=Path(sys.argv[1])
pairs={"scripts/main.gd":[('''	_storage_title.text = "Склад  ·  %d / %d місць" % [used, total]
	if GameState.phase == GameState.Phase.SERVICE and not GameState.awaiting_quest:
		_storage_view.highlight = [GameState.current_customer["tag"]]
	elif GameState.phase == GameState.Phase.SERVICE:
		_storage_view.highlight = GameData.HERO_ITEM_CATEGORIES
	else:
		_storage_view.highlight = []
''','''	_storage_title.text = "Склад  ·  %d / %d місць" % [used, total]
	_storage_view.refresh()
''')],"docs/DESIGN.md":[('''Під час обслуговування сховище з потрібною клієнту категорією підсвічується золотою рамкою.
''','')]}
out={}
for f,ps in pairs.items():
    t=(r/f).read_text(encoding="utf-8")
    for a,b in ps:
        if t.count(a)!=1: sys.exit("miss "+f)
        t=t.replace(a,b)
    out[f]=t
for f,t in out.items():
    (r/f).write_text(t,encoding="utf-8",newline="\n"); print("patched",f)
