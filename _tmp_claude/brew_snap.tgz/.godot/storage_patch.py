#!/usr/bin/env python3
"""Replaces the tetris storage with separate storages per category.
Usage: python3 patch.py <project dir>. Edits game_data.gd, game_state.gd, main.gd, docs in place.
Every replacement must match exactly once, otherwise nothing is written."""
import re
import sys
from pathlib import Path

root = Path(sys.argv[1])
pending = {}


def load(rel):
    if rel not in pending:
        pending[rel] = (root / rel).read_text(encoding="utf-8")
    return pending[rel]


def sub(rel, old, new, count=1):
    text = load(rel)
    n = text.count(old)
    if n != count:
        sys.exit(f"{rel}: expected {count} match(es), found {n}:\n{old[:200]}")
    pending[rel] = text.replace(old, new)


# ---------------- game_data.gd ----------------
GD = "scripts/game_data.gd"
sub(GD, '''## The storage is a fixed grid. Every item takes cells in the shape of a tetris-like piece.
## For now every shape is a full rectangle (all "#"), and the icon is stretched over it.
const STORAGE_WIDTH := 12
const STORAGE_HEIGHT := 5
''', '''## The tavern has several separate storage places. Each one keeps only its categories ("cats")
## and holds "capacity" pieces (any item = 1 piece). Every category must be in exactly one place.
## Capacities are fixed for now (no upgrades in MVP). Change, add or rename places here; the UI picks them up.
const STORAGES := {
	"pantry": {"name": "Комора", "cats": ["food"], "capacity": 12,
		"desc": "Полиці з хлібом, копченим м'ясом і горщиками рагу."},
	"cellar": {"name": "Погріб", "cats": ["drink"], "capacity": 12,
		"desc": "Прохолодний погріб під залою: бочки елю, медовуха, вино."},
	"cabinet": {"name": "Шафа", "cats": ["potion"], "capacity": 8,
		"desc": "Шафа з дверцятами на замку. Тут стоять готові зілля."},
	"chest": {"name": "Скриня", "cats": ["gear", "magic"], "capacity": 6,
		"desc": "Важка окута скриня: спорядження для героїв і магічні речі. Усе, що герої можуть узяти з собою і повернути."},
	"attic": {"name": "Горище", "cats": ["resource"], "capacity": 20,
		"desc": "Під дахом сушаться трави й коріння, у кутку лежать мішки з кістками, прахом і кристалами."},
}
''')
sub(GD, '''## shape: rows of cells, "#" = taken, "." = free. The icon stretches over the whole rectangle of rows.
''', '')
items_block_start = load(GD).index("const ITEMS := {")
items_block_end = load(GD).index("# ---------- Locations ----------")
block = load(GD)[items_block_start:items_block_end]
new_block, n = re.subn(r' "shape": \[[^\]]*\],', '', block)
if n != 23:
    sys.exit(f"expected 23 shapes, found {n}")
pending[GD] = load(GD)[:items_block_start] + new_block + load(GD)[items_block_end:]
sub(GD, '''## Whatever does not fit into the storage is left behind.''',
    '''## Whatever does not fit into its storage place is left behind.''')
sub(GD, '''## Size of the rectangle the item's icon covers, in cells (before rotation).
static func shape_size(id: String) -> Vector2i:
	var rows: Array = ITEMS[id]["shape"]
	return Vector2i(String(rows[0]).length(), rows.size())


static func shape_cell_count(id: String) -> int:
	var n := 0
	for row in ITEMS[id]["shape"]:
		n += String(row).count("#")
	return n
''', '''## Id of the storage place that keeps this category (see STORAGES).
static func storage_of_category(cat: String) -> String:
	for place_id in STORAGES:
		if cat in STORAGES[place_id]["cats"]:
			return place_id
	push_error("No storage place for category: " + cat)
	return ""


static func storage_name_of(item_id: String) -> String:
	return STORAGES[storage_of_category(ITEMS[item_id]["cat"])]["name"]
''')

# ---------------- game_state.gd ----------------
GS = "scripts/game_state.gd"
sub(GS, '''			storage.auto_place(id)''', '''			storage.add(id)''')
sub(GS, '''		_log("[color=salmon]%s «%s» не вийде: на складі немає місця для такої фігури.[/color]" % [verb, item_name])''',
    '''		_log("[color=salmon]%s «%s» не вийде: у сховищі «%s» немає місця.[/color]" % [verb, item_name, GameData.storage_name_of(item_id)])''')
sub(GS, '''	storage.auto_place(item_id)
	day_stats["spent"] += cost''', '''	storage.add(item_id)
	day_stats["spent"] += cost''')
sub(GS, '''	var backup: Array[Dictionary] = storage.pieces.duplicate(true)''', '''	var backup := storage.snapshot()''')
sub(GS, '''		if storage.auto_place(potion_id) < 0:
			storage.pieces = backup
			last_brew = {"item": potion_id, "ok": false}
			_log("[color=salmon]Зварити «%s» не вийде: для зілля немає місця на складі.[/color]" % potion_name)''',
    '''		if not storage.add(potion_id):
			storage.restore(backup)
			last_brew = {"item": potion_id, "ok": false}
			_log("[color=salmon]Зварити «%s» не вийде: у сховищі «%s» немає місця.[/color]" % [potion_name, GameData.storage_name_of(potion_id)])''')
sub(GS, '''	# Roll everything first, then store the biggest pieces first so they pack better.
	var rolled: Array[String] = []''', '''	var rolled: Array[String] = []''')
sub(GS, '''	rolled.sort_custom(func(a: String, b: String) -> bool: return GameData.shape_cell_count(a) > GameData.shape_cell_count(b))
''', '')
sub(GS, '''		if storage.auto_place(id) >= 0:
			found[id]''', '''		if storage.add(id):
			found[id]''')
sub(GS, '''		text += " [color=salmon]Не влізло на склад, залишено: %s.[/color]" % _items_text(left)''',
    '''		text += " [color=salmon]Не влізло (немає місця: %s), залишено: %s.[/color]" % [_places_text(left), _items_text(left)]''')
sub(GS, '''## The player rearranged the storage (drag and drop in the UI).
func move_piece(uid: int, pos: Vector2i, rot: int) -> bool:
	if phase == Phase.GAME_OVER:
		return false
	var ok := storage.move(uid, pos, rot)
	changed.emit()
	return ok


''', '')
sub(GS, '''func _items_text(counts: Dictionary) -> String:''', '''## Names of the storage places these items belong to, e.g. "Горище".
func _places_text(counts: Dictionary) -> String:
	var names: PackedStringArray = []
	for id in counts:
		var place_name := GameData.storage_name_of(id)
		if not place_name in names:
			names.append(place_name)
	return ", ".join(names)


func _items_text(counts: Dictionary) -> String:''')
sub(GS, '''## Puts an item that a hero brought into storage. If there is no room, sells it at once.''',
    '''## Puts an item that a hero brought into its storage place. If there is no room, sells it at once.''')
sub(GS, '''	if storage.auto_place(item_id) >= 0:
		return ""''', '''	if storage.add(item_id):
		return ""''')
sub(GS, '''	return " (на складі немає місця, продано за %s)" % Wallet.format_amount(money, true)''',
    '''	return " (у сховищі «%s» немає місця, продано за %s)" % [GameData.storage_name_of(item_id), Wallet.format_amount(money, true)]''')

# ---------------- main.gd ----------------
M = "scripts/main.gd"
sub(M, '''	_storage_view = StorageView.new()
	_storage_view.custom_minimum_size = Vector2(GameData.STORAGE_WIDTH, GameData.STORAGE_HEIGHT) * 34
	_storage_view.size_flags_vertical = Control.SIZE_EXPAND_FILL''', '''	_storage_view = StorageView.new()
	_storage_view.custom_minimum_size = Vector2(400, 0)
	_storage_view.size_flags_vertical = Control.SIZE_EXPAND_FILL''')
sub(M, '''	_storage_title.text = "Склад  ·  зайнято %d / %d клітинок" % [st.used_cells(), st.total_cells()]
	_storage_view.queue_redraw()
''', '''	var used := 0
	var total := 0
	for place_id in GameData.STORAGES:
		used += st.used(place_id)
		total += st.capacity(place_id)
	_storage_title.text = "Склад  ·  %d / %d місць" % [used, total]
	if GameState.phase == GameState.Phase.SERVICE and not GameState.awaiting_quest:
		_storage_view.highlight = [GameState.current_customer["tag"]]
	elif GameState.phase == GameState.Phase.SERVICE:
		_storage_view.highlight = GameData.HERO_ITEM_CATEGORIES
	else:
		_storage_view.highlight = []
''')
sub(M, '''	var controls := "[color=#b8a48c]На складі:[/color] клік бере предмет, ще клік кладе. ПКМ або R повертає фігуру, Esc скасовує."
''', '''	var controls := "[color=#b8a48c]Кожна категорія лежить у своєму сховищі з власною місткістю: комора, погріб, шафа, скриня, горище.[/color]"
''')
sub(M, '''		_side_hint.text = "Клік купує 1 шт. і кладе її на склад, якщо є місце. Зілля не продаються: їх вариш сам у вікні «Алхімія».\\n" + controls''',
    '''		_side_hint.text = "Клік купує 1 шт. і кладе її у своє сховище, якщо там є місце. Зілля не продаються: їх вариш сам у вікні «Алхімія».\\n" + controls''')
sub(M, '''		"[color=#%s]%s[/color]  ·  %d кліт." % [cat["color"], cat["name"], GameData.shape_cell_count(id)],''',
    '''		"[color=#%s]%s[/color]  ·  зберігається: %s" % [cat["color"], cat["name"], GameData.storage_name_of(id)],''')
sub(M, '''	_storage_view.cancel_hold()
''', '')

sub(M, """		b.pressed.connect(GameState.buy.bind(id))
		b.disabled = not GameState.wallet.can_afford(cost)""", """		b.pressed.connect(GameState.buy.bind(id))
		b.disabled = not GameState.wallet.can_afford(cost) or not GameState.storage.can_fit(id)
		if not GameState.storage.can_fit(id):
			b.tooltip_text += "\\nУ сховищі «%s» немає місця" % GameData.storage_name_of(id)""")

sub(M, "Інгредієнти беруться зі складу внизу, готове зілля кладеться туди ж.", "Інгредієнти беруться з горища, готове зілля ставиться в шафу (склад внизу).")
sub(M, """			_alchemy_result.text = "[color=#e08a7a]«%s» не влізе на склад навіть без інгредієнтів. Звільни місце.[/color]" % potion_name""",
    """			_alchemy_result.text = "[color=#e08a7a]«%s» не влізе: у сховищі «%s» немає місця. Продай щось звідти.[/color]" % [potion_name, GameData.storage_name_of(brew["item"])]""")
sub(M, "Знахідки йдуть на склад; що не влізе, залишиться в локації.", "Знахідки йдуть на горище; що не влізе, залишиться в локації.")

# ---------------- docs ----------------
D = "docs/DESIGN.md"
sub(D, "Кожен предмет має назву, базову ціну, опис, іконку та фігуру на складі.",
    "Кожен предмет має назву, базову ціну, опис та іконку. Розміру чи фігури предмети не мають: кожен займає одне місце у своєму сховищі.")
sub(D, "Інгредієнти беруться зі складу, готове зілля кладеться туди ж. Якщо зілля не влазить навіть\nпісля того, як інгредієнти забрано, нічого не відбувається.",
    "Інгредієнти беруться з горища, готове зілля ставиться в шафу. Якщо в шафі немає місця, нічого не відбувається.")
sub(D, "знайдене саме стає на склад\n(спершу великі фігури), а що не влізло, залишається в локації.",
    "знайдене саме йде на горище,\nа що не влізло, залишається в локації.")
start = load(D).index("## Склад\n")
end = load(D).index("## Процвітання міста")
pending[D] = load(D)[:start] + """## Склад
Склад поділено на окремі сховища, кожне для своїх категорій і зі своєю місткістю.
Місткість фіксована (покращень у MVP немає). Кожен предмет займає одне місце.
Усе задано в `STORAGES` у `scripts/game_data.gd`: назву, категорії й місткість можна змінити там.

| Сховище | Що там лежить | Місць |
|---|---|---|
| Комора | їжа | 12 |
| Погріб | напої | 12 |
| Шафа | зілля | 8 |
| Скриня | спорядження героїв і магічні речі | 6 |
| Горище | ресурси (трави, коріння, кістки, прах, есенція, кристали) | 20 |

Якщо у сховищі немає місця, купити на ринку не вийде (кнопка неактивна), зілля не звариться,
а знахідки з локації залишаться там. Якщо герой повертає річ або приносить трофей, а місця немає,
річ одразу продається за половину ціни.
Під час обслуговування сховище з потрібною клієнту категорією підсвічується золотою рамкою.

""" + load(D)[end:]
sub(D, "| Запаси | 18 предметів на складі-сітці (див. «Предмети») |", "| Запаси | предмети в п'яти сховищах (див. «Склад») |")
sub(D, "- **Склад** (низ ліворуч): сітка з фігурами предметів.", "- **Склад** (низ ліворуч): п'ять сховищ (комора, погріб, шафа, скриня, горище), у кожному видно заповненість і предмети з кількістю.")
R = "README.md"
sub(R, "предмети, категорії, фігури, клієнти,", "предмети, категорії, сховища складу, клієнти,")
sub(R, "- `scripts/storage.gd`: склад-сітка, де предмети лежать фігурами як у тетрісі.",
    "- `scripts/storage.gd`: склад з окремих сховищ за категоріями (місткість у `STORAGES`).")
sub(R, "- `scripts/storage_view.gd`: малює склад і дає переставляти предмети мишею.",
    "- `scripts/storage_view.gd`: показує сховища, їхню заповненість і предмети.")

for rel, text in pending.items():
    (root / rel).write_text(text, encoding="utf-8", newline="\n")
    print("patched", rel)
