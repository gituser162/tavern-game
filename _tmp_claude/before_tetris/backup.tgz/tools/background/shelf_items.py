"""Stock on the shelves under the counter (run from gen_bg6.py, which defines the palette, the light and MULT).
Every storage compartment has slots; every item that can stand in a slot gets its own sprite, lit with the very
same light as the background at that spot (so a bottle on the left looks just like the painted shelf behind it).
Output (env SHELF_OUT = folder of the Godot project):
  assets/objects/shelf_items.png  - atlas with all baked sprites
  scripts/shelf_layout.gd         - SLOTS {place: [Vector2i]} and SPRITES {"place/slot/item": [atlas Rect2i, bg pos Vector2i]}
"""
import os

SHELF_BASE = SHELF - 1      # objects on the middle shelf stand on this row
FLOOR_BASE = UY1 - 5        # objects on the floor plank
# place id: (x0, x1, pieces per row, item ids). Two rows each: shelf, then floor. 2 * per_row = capacity.
SHELF_PLACES = {
    "cellar": (3, 74, 6, ["ale", "mead", "wine"]),
    "pantry": (78, 150, 6, ["bread", "chicken", "stew"]),
    "chest": (154, 226, 3, ["shield", "chainmail", "axe", "fire_scroll", "moon_amulet", "sapphire_ring"]),
    "cabinet": (230, 296, 4, ["heal_potion", "antidote", "strength_potion"]),
}


class Layer:
    def __init__(self):
        self.rgb = np.zeros((H, W, 3), np.float32)
        self.a = np.zeros((H, W), bool)

    def px(self, x, y, c):
        if 0 <= x < W and 0 <= y < H:
            self.rgb[y, x] = hx(c)
            self.a[y, x] = True

    def rect(self, x0, y0, x1, y1, c):
        for yy in range(y0, y1):
            for xx in range(x0, x1):
                self.px(xx, yy, c)

    def h(self, x0, x1, y, c):
        self.rect(x0, y, x1, y + 1, c)

    def v(self, x, y0, y1, c):
        self.rect(x, y0, x + 1, y1, c)

    def disc(self, cx, cy, r, c):
        for yy in range(-r, r + 1):
            for xx in range(-r, r + 1):
                if xx * xx + yy * yy <= r * r + r * 0.6:
                    self.px(cx + xx, cy + yy, c)

    def outline(self):
        """Dark 1px outline around everything drawn (like the painted props)."""
        a = self.a.copy()
        edge = np.zeros_like(a)
        edge[1:, :] |= a[:-1, :]; edge[:-1, :] |= a[1:, :]; edge[:, 1:] |= a[:, :-1]; edge[:, :-1] |= a[:, 1:]
        edge &= ~a
        self.rgb[edge] = hx(OUT)
        self.a |= edge


# ---------- sprites: f(L, cx, b) draws the item centred on cx, standing on row b ----------

def s_ale(L, cx, b):          # small barrel of ale with iron hoops and a tap
    x0 = cx - 4
    for yy in range(b - 10, b + 1):
        bulge = 1 if b - 8 <= yy <= b - 2 else 0
        L.h(x0 - bulge, x0 + 9 + bulge, yy, "6a4426")
        L.px(x0 - bulge, yy, "8a6038"); L.px(x0 + 8 + bulge, yy, "4a2e1c")
    for xx in (x0 + 2, x0 + 5):
        L.v(xx, b - 9, b, "5a3820")
    for yy in (b - 8, b - 2):
        L.h(x0 - 1, x0 + 10, yy, "55555c")
    L.h(x0, x0 + 9, b - 10, "8a6038")
    L.px(cx, b - 5, BRASS); L.px(cx, b - 4, BRASS_HI)


def s_mead(L, cx, b):         # drinking horn of mead on a little wooden stand
    L.rect(cx - 4, b - 1, cx + 5, b + 1, "5a3a22"); L.h(cx - 4, cx + 5, b - 1, "7a5232")
    L.v(cx - 3, b - 4, b - 1, "5a3a22"); L.v(cx + 3, b - 4, b - 1, "5a3a22")
    horn = [(-4, 12), (-3, 11), (-2, 10), (-1, 9), (0, 8), (1, 7), (2, 6), (3, 6), (4, 7)]
    for i, (dx, top) in enumerate(horn):
        h_ = max(1, 4 - i // 2)
        L.v(cx + dx, b - top, b - top + h_ + 1, "d8c8a0" if i < 6 else "8a6a42")
    L.h(cx - 4, cx - 1, b - 12, BRASS)
    L.px(cx - 3, b - 13, "e0a030"); L.px(cx - 2, b - 13, "f0c050")   # honey at the rim


def s_wine(L, cx, b):         # slim bottle of elven wine with a green label
    L.rect(cx - 2, b - 11, cx + 3, b + 1, "5a1e3a")
    L.v(cx - 1, b - 10, b - 1, "8a3a5a")
    L.rect(cx - 1, b - 15, cx + 2, b - 11, "4a1830")
    L.rect(cx - 1, b - 17, cx + 2, b - 15, "c8a868")
    L.rect(cx - 2, b - 7, cx + 3, b - 4, "4a8a5a"); L.px(cx, b - 6, BRASS_HI)


def s_bread(L, cx, b):        # rye loaf
    for yy in range(b - 5, b + 1):
        half = [3, 4, 5, 5, 5, 5][yy - (b - 5)]
        L.h(cx - half, cx + half + 1, yy, "8a5a2e")
        L.px(cx + half, yy, "5a3a1a")
    L.h(cx - 2, cx + 3, b - 5, "a87440")
    for k in (-2, 1, 4):
        L.px(cx + k - 1, b - 3, "5a3a1a"); L.px(cx + k, b - 4, "5a3a1a")


def s_chicken(L, cx, b):      # roast chicken on a plate
    L.h(cx - 5, cx + 6, b, "b8b0a0"); L.h(cx - 4, cx + 5, b - 1, "d8d0c0")
    for yy in range(b - 6, b - 1):
        half = [3, 4, 4, 4, 3][yy - (b - 6)]
        L.h(cx - half, cx + half + 1, yy, "c07a32")
        L.px(cx - half, yy, "e0a050")
    L.h(cx - 2, cx + 2, b - 6, "e0a050")
    L.px(cx + 4, b - 7, "c07a32"); L.px(cx + 5, b - 8, "e8e0d0"); L.px(cx + 6, b - 8, "e8e0d0")   # drumstick
    L.px(cx - 4, b - 7, "c07a32"); L.px(cx - 5, b - 8, "e8e0d0")


def s_stew(L, cx, b):         # iron pot of venison stew
    for yy in range(b - 6, b + 1):
        half = [5, 5, 5, 5, 4, 4, 3][yy - (b - 6)]
        L.h(cx - half, cx + half + 1, yy, "3a3a42")
        L.px(cx - half + 1, yy, "5a5a64")
    L.h(cx - 5, cx + 6, b - 7, "4a4a52")
    L.h(cx - 4, cx + 5, b - 7, "7a3e22"); L.px(cx - 1, b - 7, "a85a2a"); L.px(cx + 2, b - 7, "6a8a3a")
    L.px(cx - 6, b - 5, "3a3a42"); L.px(cx + 6, b - 5, "3a3a42")      # ears
    L.px(cx - 1, b - 9, "6a5a50"); L.px(cx + 1, b - 10, "6a5a50")      # steam


def s_heal(L, cx, b):         # round red flask
    L.disc(cx, b - 4, 4, "a82a2a")
    L.px(cx - 2, b - 6, "e87060"); L.px(cx - 2, b - 5, "c84a40")
    L.rect(cx - 1, b - 11, cx + 2, b - 8, "8a9a9a")
    L.rect(cx - 1, b - 13, cx + 2, b - 11, "8a6a42")


def s_antidote(L, cx, b):     # tall green vial
    L.rect(cx - 2, b - 10, cx + 3, b + 1, "3a8a3a")
    L.v(cx - 1, b - 9, b - 1, "7ac86a")
    L.h(cx - 2, cx + 3, b - 10, "8a9a9a")
    L.rect(cx - 1, b - 13, cx + 2, b - 10, "9aaaaa")
    L.rect(cx - 1, b - 15, cx + 2, b - 13, "8a6a42")


def s_strength(L, cx, b):     # square orange bottle with a bull label
    L.rect(cx - 3, b - 8, cx + 4, b + 1, "c8702a")
    L.v(cx - 2, b - 7, b - 1, "f0a050")
    L.rect(cx - 1, b - 11, cx + 2, b - 8, "8a9a9a")
    L.rect(cx - 1, b - 13, cx + 2, b - 11, "8a6a42")
    L.rect(cx - 1, b - 5, cx + 2, b - 2, "e8dcc0"); L.px(cx, b - 4, "5a1e1e")


def s_shield(L, cx, b):       # round oak shield standing on its edge
    r = 8
    cy = b - r
    for yy in range(-r, r + 1):
        for xx in range(-r, r + 1):
            d2 = xx * xx + yy * yy
            if d2 <= r * r + 3:
                c = "8a5a2e" if (xx + 7) // 3 % 2 == 0 else "7a4e26"
                if d2 >= (r - 1) ** 2:
                    c = "55555c"
                L.px(cx + xx, cy + yy, c)
    L.disc(cx, cy, 2, "8a8e96"); L.px(cx - 1, cy - 1, "c8ccd4")


def s_chainmail(L, cx, b):    # chainmail shirt on a wooden stand
    L.v(cx, b - 3, b + 1, "5a3a22"); L.h(cx - 3, cx + 4, b, "5a3a22")
    L.h(cx - 6, cx + 7, b - 14, "5a3a22")
    for yy in range(b - 13, b - 2):
        half = 6 if yy < b - 9 else 4
        for xx in range(cx - half, cx + half + 1):
            L.px(xx, yy, "9a9ea6" if (xx + yy) % 2 == 0 else "6a6e76")
    L.h(cx - 2, cx + 3, b - 13, "3a3a42")
    L.h(cx - 4, cx + 5, b - 3, "8a6a42")


def s_axe(L, cx, b):          # battle axe leaning upright
    L.v(cx, b - 17, b + 1, "6a4426"); L.v(cx + 1, b - 17, b + 1, "8a6038")
    for yy in range(b - 17, b - 9):
        t = yy - (b - 17)
        w_ = [3, 4, 5, 5, 5, 5, 4, 3][t]
        L.h(cx + 2, cx + 2 + w_, yy, "9a9ea6")
        L.px(cx + 1 + w_, yy, "d8dce4")
    L.rect(cx - 3, b - 15, cx, b - 11, "7a7e86")
    L.px(cx, b - 18, "55555c")


def s_scroll(L, cx, b):       # rolled scroll of fire with a red seal
    L.rect(cx - 6, b - 3, cx + 7, b + 1, "e8d8b0")
    L.v(cx - 6, b - 3, b + 1, "c8b890"); L.v(cx + 6, b - 3, b + 1, "c8b890")
    L.h(cx - 6, cx + 7, b - 3, "f0e4c4")
    L.v(cx - 7, b - 2, b, "a8987a"); L.v(cx + 7, b - 2, b, "a8987a")
    L.rect(cx - 1, b - 2, cx + 2, b + 1, "c83a1a"); L.px(cx, b - 3, "f07a2a")
    L.px(cx, b - 5, "f0a03a"); L.px(cx + 1, b - 6, "e0582a")   # a tiny flame above it


def s_amulet(L, cx, b):       # silver crescent amulet on a velvet bust
    for yy in range(b - 12, b + 1):
        t = yy - (b - 12)
        half = 2 if t < 3 else min(6, 2 + (t - 2))
        L.h(cx - half, cx + half + 1, yy, "2a2a4a")
        L.px(cx - half, yy, "3a3a5e")
    L.h(cx - 6, cx + 7, b, "1e1e36")
    for k in range(5):                                   # gold chain in a V
        L.px(cx - 4 + k, b - 9 + k, BRASS); L.px(cx + 4 - k, b - 9 + k, BRASS)
    for yy, xs in ((-4, (-2, -1, 1, 2)), (-3, (-2, 2)), (-2, (-1, 0, 1))):
        for dx in xs:
            L.px(cx + dx, b + yy, "d8dce8")
    L.px(cx, b - 3, "8ab8f0")


def s_ring(L, cx, b):         # sapphire ring on a velvet cushion
    for yy in range(b - 2, b + 1):
        half = 5 if yy > b - 2 else 4
        L.h(cx - half, cx + half + 1, yy, "6a2a6a")
    L.h(cx - 4, cx + 5, b - 2, "8a3a8a")
    L.px(cx - 5, b, "c8a03a"); L.px(cx + 5, b, "c8a03a")
    L.px(cx - 1, b - 3, BRASS); L.px(cx + 1, b - 3, BRASS); L.px(cx - 2, b - 4, BRASS); L.px(cx + 2, b - 4, BRASS)
    L.px(cx - 1, b - 5, BRASS); L.px(cx + 1, b - 5, BRASS)
    L.px(cx, b - 6, "3a6ae0"); L.px(cx, b - 5, "1e3a9a"); L.px(cx - 1, b - 6, "8ab0ff")


SPRITE_FN = {
    "ale": s_ale, "mead": s_mead, "wine": s_wine,
    "bread": s_bread, "chicken": s_chicken, "stew": s_stew,
    "heal_potion": s_heal, "antidote": s_antidote, "strength_potion": s_strength,
    "shield": s_shield, "chainmail": s_chainmail, "axe": s_axe,
    "fire_scroll": s_scroll, "moon_amulet": s_amulet, "sapphire_ring": s_ring,
}


def slot_positions(place):
    x0, x1, n, _ = SHELF_PLACES[place]
    pitch = (x1 - x0) / n
    out_ = []
    for base in (SHELF_BASE, FLOOR_BASE):
        for i in range(n):
            out_.append((int(round(x0 + pitch * (i + 0.5))), base))
    return out_


def bake(fn, cx, b):
    L = Layer()
    fn(L, cx, b)
    L.outline()
    ys, xs = np.nonzero(L.a)
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    lit = np.clip(L.rgb[y0:y1, x0:x1] * MULT[y0:y1, x0:x1], 0, 255).astype(np.uint8)
    alpha = (L.a[y0:y1, x0:x1] * 255).astype(np.uint8)
    return np.dstack([lit, alpha]), (int(x0), int(y0))


SHELF_OUT = os.environ.get("SHELF_OUT")
if SHELF_OUT:
    sprites = []      # (key, rgba, bg pos)
    slots = {}
    for place in SHELF_PLACES:
        slots[place] = slot_positions(place)
        for si, (cx, b) in enumerate(slots[place]):
            for item in SHELF_PLACES[place][3]:
                rgba, pos = bake(SPRITE_FN[item], cx, b)
                sprites.append(("%s/%d/%s" % (place, si, item), rgba, pos))
    # pack into rows of an atlas 256 px wide
    AW, x_, y_, row_h = 256, 0, 0, 0
    placed = []
    for key, rgba, pos in sprites:
        h_, w_ = rgba.shape[:2]
        if x_ + w_ > AW:
            x_, y_, row_h = 0, y_ + row_h + 1, 0
        placed.append((key, x_, y_, w_, h_, pos))
        x_ += w_ + 1
        row_h = max(row_h, h_)
    atlas = np.zeros((y_ + row_h + 1, AW, 4), np.uint8)
    for (key, ax, ay, w_, h_, pos), (_, rgba, _) in zip(placed, sprites):
        atlas[ay:ay + h_, ax:ax + w_] = rgba
    Image.fromarray(atlas, "RGBA").save(os.path.join(SHELF_OUT, "assets/objects/shelf_items.png"))
    lines = [
        "extends RefCounted",
        "## GENERATED by tools/background/gen_bg6.py + shelf_items.py - do not edit by hand.",
        "## Stock drawn on the shelves under the counter. Every storage compartment has slots (bg px, the spot the item",
        "## stands on). Every item that fits a slot has a sprite baked with the background light at that spot.",
        "",
        'const ATLAS := "res://assets/objects/shelf_items.png"',
        "",
        "## place id -> [slot position (bg px: centre x, row it stands on)]; first the middle shelf, then the floor.",
        "const SLOTS := {",
    ]
    for place, sl in slots.items():
        lines.append('\t"%s": [%s],' % (place, ", ".join("Vector2i(%d, %d)" % s for s in sl)))
    lines += ["}", "", '## "place/slot/item" -> [region in ATLAS, top-left corner on the background (bg px)]', "const SPRITES := {"]
    for key, ax, ay, w_, h_, pos in placed:
        lines.append('\t"%s": [Rect2i(%d, %d, %d, %d), Vector2i(%d, %d)],' % (key, ax, ay, w_, h_, pos[0], pos[1]))
    lines += ["}", ""]
    open(os.path.join(SHELF_OUT, "scripts/shelf_layout.gd"), "w", encoding="utf-8").write("\n".join(lines))
    # preview: the background with every slot full (first item kind per place, then cycling)
    prev = np.clip(out, 0, 255).astype(np.uint8).copy()
    for key, rgba, pos in sprites:
        place, si, item = key.split("/")
        items = SHELF_PLACES[place][3]
        if items[int(si) % len(items)] != item:
            continue
        h_, w_ = rgba.shape[:2]
        m = rgba[..., 3] > 0
        prev[pos[1]:pos[1] + h_, pos[0]:pos[0] + w_][m] = rgba[..., :3][m]
    Image.fromarray(prev, "RGB").resize((W * 4, H * 4), Image.NEAREST).save(os.path.join(SHELF_OUT, "shelf_preview.png"))
    print("shelf sprites:", len(sprites), "atlas", atlas.shape)
